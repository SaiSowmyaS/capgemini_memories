package com.cg.assessment.entities;

import java.util.Scanner;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;



public class AssessmentMain {
	public static void main(String[] args) {
		
	
Scanner sc=new Scanner(System.in);
	
	
	EntityManagerFactory factory = 
			Persistence.createEntityManagerFactory("JPA-PU");
	EntityManager em = factory.createEntityManager();
	em.getTransaction().begin();
	AssessmentBean assessmentBean=new AssessmentBean();
	System.out.println("enter id");
	int id=sc.nextInt();
	assessmentBean.setDetails_Id(id);
	System.out.println("Enter the trainee name:");
	String tname=sc.next();
	assessmentBean.setTrainee_Name(tname);
	System.out.println("Enter the Module name: ");
	String mname=sc.next();
	assessmentBean.setModule_Name(mname);
	System.out.println("Enter the mpt score: ");
	double mpt=sc.nextDouble();
	assessmentBean.setMpt_Score(mpt);
	System.out.println("Enter the mtt score :");
	double mtt=sc.nextDouble();
	assessmentBean.setMtt_Score(mtt);
	System.out.println("Enter the assignment score: ");
	double assign=sc.nextDouble();
	assessmentBean.setAssignment_Mark(assign);
	double total_mark=assessmentBean.getMpt_Score()+assessmentBean.getMtt_Score()+assessmentBean.getAssignment_Mark();
	System.out.println("The total score for 100 is :"+ total_mark);
	assessmentBean.setTotal(total_mark);
    em.persist(assessmentBean);
	
	
	System.out.println("details are added");
	
	
	em.getTransaction().commit();
	em.close();
	factory.close();
	}
}
