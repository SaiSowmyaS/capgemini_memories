package com.cg.assessment.entities;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;



@Entity
@Table(name="Trainee_details")

public class AssessmentBean implements Serializable {
	private static final long serialVersionUID = 1L;
	@Id
	private int details_Id;
	private String trainee_Name;
	private String module_Name;
	private double mpt_Score;
	private double mtt_Score;
	private double assignment_Mark;
	private double total;
	public int getDetails_Id() {
		return details_Id;
	}
	public void setDetails_Id(int details_Id) {
		this.details_Id = details_Id;
	}
	public String getTrainee_Name() {
		return trainee_Name;
	}
	public void setTrainee_Name(String trainee_Name) {
		this.trainee_Name = trainee_Name;
	}
	public String getModule_Name() {
		return module_Name;
	}
	public void setModule_Name(String module_Name) {
		this.module_Name = module_Name;
	}
	public double getMpt_Score() {
		return mpt_Score;
	}
	public void setMpt_Score(double mpt_Score) {
		this.mpt_Score = mpt_Score;
	}
	public double getMtt_Score() {
		return mtt_Score;
	}
	public void setMtt_Score(double mtt_Score) {
		this.mtt_Score = mtt_Score;
	}
	public double getAssignment_Mark() {
		return assignment_Mark;
	}
	public void setAssignment_Mark(double assignment_Mark) {
		this.assignment_Mark = assignment_Mark;
	}
	public double getTotal() {
		return total;
	}
	public void setTotal(double total) {
		this.total = total;
	}
	@Override
	public String toString() {
		return "AssessmentBean [details_Id=" + details_Id + ", trainee_Name=" + trainee_Name + ", module_Name="
				+ module_Name + ", mpt_Score=" + mpt_Score + ", mtt_Score=" + mtt_Score + ", assignment_Mark="
				+ assignment_Mark + ", total=" + total + "]";
	}
	

}
